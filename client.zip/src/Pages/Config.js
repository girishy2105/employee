let posturl = 'http://localhost:5001/employee'

let geturl = 'http://localhost:5001/employee/get'

let puturl = 'http://localhost:5001/employee/put'

let delurl = 'http://localhost:5001/employee/:code'

let post = 'http://localhost:5001/department'

let get = 'http://localhost:5001/department/get'

let put = 'http://localhost:5001/department/depput'

module.exports = { posturl, geturl, delurl, puturl, post, get, put }
